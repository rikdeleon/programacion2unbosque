package co.edu.unbosque.modelo.persistence;

public class Archivo {

}
