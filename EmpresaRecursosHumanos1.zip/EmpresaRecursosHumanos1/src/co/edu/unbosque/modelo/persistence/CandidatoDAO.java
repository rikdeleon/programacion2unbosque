package co.edu.unbosque.modelo.persistence;

import java.util.ArrayList;

import co.edu.unbosque.modelo.CandidatoDTO;

public class CandidatoDAO {
	
	private Archivo archivo;
	
	public void  eliminar(int cedula, ArrayList<CandidatoDTO> candidatos) {
		
	}
	
	public void crear(String nombre, String apellido, String cedula, String cargo, String edad, ArrayList<CandidatoDTO> candidatos) {
		
	}
	
	public void actualizar(String nombre, String apellido, String cedula, String cargo, String edad, ArrayList<CandidatoDTO> candidatos) {
		
	}
	public void buscar( String cedula, ArrayList<CandidatoDTO> candidatos) {
	
	}

}
