package co.edu.unbosque.modelo;

import java.io.Serializable;

public class CandidatoDTO implements Serializable{

	private static final long serialVersionUID = 1L; 
	private String nombre;
	private String apellido;
	private String cedula;
	private String cargo;
	private String edad;
	
	public CandidatoDTO(String nombre, String apellido, String cedula, String cargo, String edad) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.cedula = cedula;
		this.cargo = cargo;
		this.edad = edad;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getCedula() {
		return cedula;
	}

	public void setCedula(String cedula) {
		this.cedula = cedula;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public String getEdad() {
		return edad;
	}

	public void setEdad(String edad) {
		this.edad = edad;
	}

	@Override
	public String toString() {
		return "Nombre =" + nombre + " apellido=" + apellido + ", cedula=" + cedula + ", cargo=" + cargo
				+ ", edad=" + edad + "]";
	}
	
	
	
	
	
}
