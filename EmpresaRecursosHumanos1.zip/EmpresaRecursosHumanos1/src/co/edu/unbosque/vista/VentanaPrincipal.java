package co.edu.unbosque.vista;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class VentanaPrincipal extends JFrame{
	
	private JFrame ventana1;
	private JLabel buscar;
	private JLabel nombre;
	private JLabel apellido;
	private JLabel cedula;
	private JLabel edad;
	private JTextField nombre1;
	private JTextField apellido1;
	private JTextField cedula1;
	private JTextField edad1;
	private JButton nuevo_candidato;
	private JComboBox<String> candidatos;
	
	 
	public VentanaPrincipal() {
		
		setTitle("EMPRESA RRH");
		setSize(WIDTH, HEIGHT);
	}
	

}
