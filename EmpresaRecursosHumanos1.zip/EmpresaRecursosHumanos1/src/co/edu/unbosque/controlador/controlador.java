package co.edu.unbosque.controlador;

public class controlador {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
